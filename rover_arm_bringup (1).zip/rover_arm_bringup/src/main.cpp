// Copyright 2026 Robotics Team
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0

#include <memory>

#include "rclcpp/rclcpp.hpp"
#include "rover_arm_bringup/rover_arm_coordinator.hpp"

int main(int argc, char ** argv)
{
  rclcpp::init(argc, argv);

  rclcpp::NodeOptions options;
  auto node = std::make_shared<rover_arm_bringup::RoverArmCoordinator>(options);

  // MultiThreadedExecutor so the reentrant service-response callback group
  // can process arm-service completions without waiting behind the
  // periodic control-loop timer callback.
  rclcpp::executors::MultiThreadedExecutor executor;
  executor.add_node(node);
  executor.spin();

  rclcpp::shutdown();
  return 0;
}
