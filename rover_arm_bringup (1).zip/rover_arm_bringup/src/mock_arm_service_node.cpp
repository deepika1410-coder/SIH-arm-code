// Copyright 2026 Robotics Team
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Lightweight mock /arm/execute_pick server for standalone integration
// testing of rover_arm_coordinator_node without real arm hardware/firmware.
// Simulates a 2-second pick-and-place cycle and always reports success.

#include <chrono>
#include <memory>
#include <thread>

#include "rclcpp/rclcpp.hpp"
#include "std_srvs/srv/trigger.hpp"

using namespace std::chrono_literals;

class MockArmService : public rclcpp::Node
{
public:
  MockArmService()
  : Node("mock_arm_service_node")
  {
    pick_duration_sec_ = this->declare_parameter<double>("pick_duration_sec", 2.0);
    service_name_ =
      this->declare_parameter<std::string>("arm_service_name", "/arm/execute_pick");

    // Executed on a dedicated callback group / thread by the MultiThreadedExecutor
    // in main() below, so the blocking sleep here does not stall the process.
    service_ = this->create_service<std_srvs::srv::Trigger>(
      service_name_,
      [this](
        const std::shared_ptr<std_srvs::srv::Trigger::Request>/*request*/,
        std::shared_ptr<std_srvs::srv::Trigger::Response> response)
      {
        RCLCPP_INFO(
          get_logger(), "Received pick-and-place request. Simulating %.1f s task...",
          pick_duration_sec_);
        std::this_thread::sleep_for(
          std::chrono::duration<double>(pick_duration_sec_));
        response->success = true;
        response->message = "Mock pick-and-place complete";
        RCLCPP_INFO(get_logger(), "Pick-and-place complete. Reporting success.");
      });

    RCLCPP_INFO(
      get_logger(), "mock_arm_service_node ready on '%s' (simulated duration %.1f s)",
      service_name_.c_str(), pick_duration_sec_);
  }

private:
  rclcpp::Service<std_srvs::srv::Trigger>::SharedPtr service_;
  double pick_duration_sec_{2.0};
  std::string service_name_{"/arm/execute_pick"};
};

int main(int argc, char ** argv)
{
  rclcpp::init(argc, argv);
  auto node = std::make_shared<MockArmService>();
  rclcpp::executors::MultiThreadedExecutor executor;
  executor.add_node(node);
  executor.spin();
  rclcpp::shutdown();
  return 0;
}
