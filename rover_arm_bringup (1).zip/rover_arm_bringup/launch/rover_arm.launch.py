#!/usr/bin/env python3
"""
Launch file for the rover_arm_bringup coordinator node.

Brings up the rover_arm_coordinator_node with configurable ROS parameters
for navigation speed, obstacle threshold, resume delay, control loop rate,
and topic/service names. All parameters can be overridden from the command
line, e.g.:

    ros2 launch rover_arm_bringup rover_arm.launch.py \
        target_speed:=0.3 obstacle_threshold:=0.20 use_sim_time:=true
"""

from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node


def generate_launch_description() -> LaunchDescription:
    # ---------------------------------------------------------------------
    # Launch arguments (override defaults from the CLI or a parent launch file)
    # ---------------------------------------------------------------------
    target_speed_arg = DeclareLaunchArgument(
        "target_speed",
        default_value="0.2",
        description="Forward navigation speed published to /cmd_vel [m/s]",
    )

    obstacle_threshold_arg = DeclareLaunchArgument(
        "obstacle_threshold",
        default_value="0.15",
        description="Obstacle distance threshold [m]; halt when range <= this value",
    )

    resume_delay_arg = DeclareLaunchArgument(
        "resume_delay_sec",
        default_value="1.0",
        description="Settle delay [s] after a successful pick before resuming navigation",
    )

    control_loop_period_arg = DeclareLaunchArgument(
        "control_loop_period_sec",
        default_value="0.05",
        description="Control loop period [s] (default 0.05 -> 20 Hz)",
    )

    cmd_vel_topic_arg = DeclareLaunchArgument(
        "cmd_vel_topic",
        default_value="/cmd_vel",
        description="Topic to publish rover velocity commands on",
    )

    range_topic_arg = DeclareLaunchArgument(
        "range_topic",
        default_value="/ultrasonic/range",
        description="Topic to subscribe to for ultrasonic range data",
    )

    arm_service_name_arg = DeclareLaunchArgument(
        "arm_service_name",
        default_value="/arm/execute_pick",
        description="Service name used to trigger the robotic arm pick-and-place routine",
    )

    use_sim_time_arg = DeclareLaunchArgument(
        "use_sim_time",
        default_value="false",
        description="Use simulation (Gazebo) clock if true",
    )

    log_level_arg = DeclareLaunchArgument(
        "log_level",
        default_value="info",
        description="Logging level for the coordinator node (debug, info, warn, error)",
    )

    # ---------------------------------------------------------------------
    # Node
    # ---------------------------------------------------------------------
    coordinator_node = Node(
        package="rover_arm_bringup",
        executable="rover_arm_coordinator_node",
        name="rover_arm_coordinator_node",
        output="screen",
        emulate_tty=True,
        arguments=["--ros-args", "--log-level", LaunchConfiguration("log_level")],
        parameters=[
            {
                "target_speed": LaunchConfiguration("target_speed"),
                "obstacle_threshold": LaunchConfiguration("obstacle_threshold"),
                "resume_delay_sec": LaunchConfiguration("resume_delay_sec"),
                "control_loop_period_sec": LaunchConfiguration("control_loop_period_sec"),
                "cmd_vel_topic": LaunchConfiguration("cmd_vel_topic"),
                "range_topic": LaunchConfiguration("range_topic"),
                "arm_service_name": LaunchConfiguration("arm_service_name"),
                "use_sim_time": LaunchConfiguration("use_sim_time"),
            }
        ],
    )

    return LaunchDescription(
        [
            target_speed_arg,
            obstacle_threshold_arg,
            resume_delay_arg,
            control_loop_period_arg,
            cmd_vel_topic_arg,
            range_topic_arg,
            arm_service_name_arg,
            use_sim_time_arg,
            log_level_arg,
            coordinator_node,
        ]
    )
