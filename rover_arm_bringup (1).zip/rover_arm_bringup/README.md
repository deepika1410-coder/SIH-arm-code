# rover_arm_bringup

Production-ready ROS 2 (Humble / Jazzy) C++ package coordinating a
differential-drive rover with a 3-DOF robotic arm via a non-blocking
Finite State Machine (FSM).

## Package layout

```
rover_arm_bringup/
├── CMakeLists.txt
├── package.xml
├── README.md
├── include/
│   └── rover_arm_bringup/
│       └── rover_arm_coordinator.hpp
├── src/
│   ├── main.cpp                     # entry point for rover_arm_coordinator_node
│   ├── rover_arm_coordinator.cpp    # FSM implementation
│   └── mock_arm_service_node.cpp    # standalone /arm/execute_pick test server
├── launch/
│   └── rover_arm.launch.py
└── config/
    └── rover_arm_params.yaml
```

## Finite State Machine

| State           | Behavior                                                                 |
|-----------------|---------------------------------------------------------------------------|
| `NAVIGATING`    | Publishes `linear.x = target_speed` on `/cmd_vel`; watches `/ultrasonic/range`. |
| `OBSTACLE_HALT` | Publishes zero velocity; issues async call to `/arm/execute_pick`.       |
| `PICKING`       | Rover held stationary while awaiting the arm service response (non-blocking). |
| `RESUME`        | On arm success, waits `resume_delay_sec`, then transitions to `NAVIGATING`. |

State transitions and topic/service traffic are logged via
`RCLCPP_INFO` / `RCLCPP_WARN` / `RCLCPP_ERROR`.

## Topics & Services

| Interface            | Type                          | Direction  |
|-----------------------|-------------------------------|------------|
| `/cmd_vel`             | `geometry_msgs/msg/Twist`     | publish    |
| `/ultrasonic/range`    | `sensor_msgs/msg/Range`       | subscribe  |
| `/arm/execute_pick`    | `std_srvs/srv/Trigger`        | client     |

All topic/service names are configurable via ROS parameters.

## Parameters

| Parameter                 | Type   | Default              | Description                                  |
|----------------------------|--------|-----------------------|-----------------------------------------------|
| `target_speed`             | double | `0.2`                 | Forward navigation speed [m/s]               |
| `obstacle_threshold`       | double | `0.15`                | Halt distance [m]                            |
| `resume_delay_sec`         | double | `1.0`                 | Settle delay before resuming [s]             |
| `control_loop_period_sec`  | double | `0.05`                | Control loop period (20 Hz default) [s]      |
| `cmd_vel_topic`            | string | `/cmd_vel`            | Velocity command topic                       |
| `range_topic`              | string | `/ultrasonic/range`   | Ultrasonic range topic                       |
| `arm_service_name`         | string | `/arm/execute_pick`   | Arm pick-and-place service name              |

## Build

```bash
cd ~/ros2_ws
colcon build --packages-select rover_arm_bringup
source install/setup.bash
```

## Run

```bash
ros2 launch rover_arm_bringup rover_arm.launch.py \
    target_speed:=0.25 obstacle_threshold:=0.20
```

## Standalone integration test (no real hardware)

Terminal 1 — mock arm server (simulates a 2 s pick-and-place cycle):

```bash
ros2 run rover_arm_bringup mock_arm_service_node
```

Terminal 2 — coordinator:

```bash
ros2 launch rover_arm_bringup rover_arm.launch.py
```

Terminal 3 — simulate an obstacle:

```bash
ros2 topic pub /ultrasonic/range sensor_msgs/msg/Range \
  "{radiation_type: 0, field_of_view: 0.3, min_range: 0.02, max_range: 4.0, range: 0.10}" -r 5
```

You should see the FSM transition `NAVIGATING -> OBSTACLE_HALT -> PICKING ->
RESUME -> NAVIGATING` in the coordinator's log output, and `/cmd_vel` drop to
zero during the halt/pick/resume window.

## Design notes

- The node uses a `rclcpp::executors::MultiThreadedExecutor` with the arm
  service client on a dedicated **Reentrant** callback group, so the async
  service response is processed independently of the periodic control-loop
  timer — no part of the FSM blocks the executor.
- `arm_request_in_flight_` guards against re-issuing the pick request on every
  control-loop tick while `OBSTACLE_HALT` is settling into `PICKING`.
- `state_mutex_` protects FSM state reads/writes since callbacks may run on
  different executor threads.
- A failed or exceptional arm service response returns the FSM to
  `OBSTACLE_HALT`, which will safely retry the pick request rather than
  silently getting stuck.
- `rclcpp_action` is declared as a dependency for straightforward migration
  to an `action_msgs`-based long-running arm interface (e.g. Nav2-style
  feedback/cancel) without a package restructure.
